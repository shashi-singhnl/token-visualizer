HOW TO RUN

Zero-warning (recommended):
  1. Right-click THIS ZIP -> Properties -> tick Unblock -> Apply
  2. Extract
  3. Double-click TokenVisualizer.vbs -- no warning, ever.

Quick run:
  1. Double-click TokenVisualizer.vbs -> click Open (one-time only)
  2. Future runs: no warning (file self-unblocks on first run)

Powered by Shashi Singh | SRA Holding BV
All decoding is local -- nothing sent to any server.
